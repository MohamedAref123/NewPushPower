﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace PowerShell
{
    public static class FileManager
    {

        public static bool Rename(string filePath,string newFilePath)
        {
            if (!File.Exists(filePath))
            {
                File.Create(filePath);
            }
            try
            {
                File.Move(filePath, newFilePath);
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        public static async Task ReadFileAsync(string filePath)
        {
            if (!File.Exists(filePath))
            {
                File.Create(filePath);
            }

            string[] lines =await File.ReadAllLinesAsync(filePath);

            foreach (string line in lines)
                Console.WriteLine(line);
        }
        public static void WriteFile(string filePath,string text)
        {
            if(!File.Exists(filePath))
            {
                File.Create(filePath);
            }
            
             File.AppendAllText(filePath, "\n"+text);
        }
        public static bool DeleteFile(string source)
        {
            if (!File.Exists(source))
            {
                return false;
            }
            try
            {
                File.Delete(source);

            }
            catch (Exception e)
            {
                return false;
            }

            return true;
        }
        public static bool CopyFile(string source,string destination)
        {
            if (!File.Exists(source))
            {
                return false;
            }
            try
            {
                File.Copy(source, destination);

            }
            catch(Exception e)
            {
                return false;
            }

            return true;

        }


    }
}
