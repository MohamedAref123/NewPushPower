﻿using System;
using System.IO;
using System.Threading.Tasks;

namespace PowerShell
{
    class Program
    {
        private static string currentDirectory="";
        private static bool exit=true;
        static async Task Main(string[] args)
        {
            string inputValue = "";
            do
            {
                string directory = getCurrentDirectory();

                Console.Write(directory + "/>");
                inputValue= Console.ReadLine();

                switch (inputValue)
                {
                    case "dir":
                        var files = Directory.GetFiles(directory);
                        for (int i = 0; i < files.Length; i++)
                        {
                            Console.WriteLine(files[i]);
                        }
                        var directories = Directory.GetDirectories(directory);
                        for (int i = 0; i < directories.Length; i++)
                        {
                            Console.WriteLine(directories[i]);
                        }
                        break;
                    case "cls":
                        Console.Clear();
                        break;
                    case "cd":
                        Console.Write(currentDirectory + "/>");
                        inputValue = Console.ReadLine();
                        try
                        {
                            var attr = File.GetAttributes(inputValue);
                            if ((attr & FileAttributes.Directory) == FileAttributes.Directory)
                            {
                                currentDirectory = inputValue;
                            }
                            else
                            {
                                Console.WriteLine("Wrong directory...");
                            }
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine("Wrong directory...");
                        }

                        break;
                    case "..":
                        var result = directory.LastIndexOf('\\');
                        currentDirectory = directory.Substring(0, directory.Length - (directory.Substring(result).Length));
                        break;
                    case "read":
                        await FileManager.ReadFileAsync(directory + "\\Test.txt");
                        break;
                    case "write":
                        Console.Write("Enter Text : ");
                        string data = Console.ReadLine();
                        FileManager.WriteFile(directory + "\\Test.txt", data);
                        break;
                    case "delete":
                        Console.Write("Enter file source : ");
                        string sourceToDelete = Console.ReadLine();
                        if (!FileManager.DeleteFile(sourceToDelete))
                        {
                            Console.WriteLine("Something wnt wrong...");

                        }
                        else
                        {
                            Console.WriteLine("Deleted successfully...");

                        }
                        break;
                    case "copy":
                        Console.Write("Enter source file : ");
                        string source = Console.ReadLine();
                        Console.Write("Enter destination file : ");
                        string destination = Console.ReadLine();

                        if (!FileManager.CopyFile(source, destination))
                        {
                            Console.WriteLine("Something went wrong...");
                        }
                        else
                        {
                            Console.WriteLine("Coppied successfully...");

                        }
                        break;
                    case "quit":
                        exit = false;
                        break;
                    case "rename":

                        Console.WriteLine("Enter file name ");
                        string oldFilePath = Console.ReadLine();
                        Console.WriteLine("Enter new file name ");
                        string newFilePath = Console.ReadLine();
                        bool created = FileManager.Rename(directory+"\\"+oldFilePath,directory + "\\" + newFilePath);
                        if (created)
                        {
                            Console.WriteLine("File renamed succefully ...");

                        }
                        else
                        {
                            Console.WriteLine("Something went wrong...");

                        }
                        break;

                    case "help":
                        help();
                        break;
                }
            }
            while (exit);
            System.Environment.Exit(0);

        }

        private static void help()
        {
            Console.WriteLine("dir    - list files and folders");
            Console.WriteLine("cd     - change directory");
            Console.WriteLine("cls    - clear window");
            Console.WriteLine("..     - back one directory");
            Console.WriteLine("read   - read file content");
            Console.WriteLine("write  - write file content");
            Console.WriteLine("copy   - copy file ");
            Console.WriteLine("delete - delete file ");
            Console.WriteLine("rename - rename file ");
            Console.WriteLine("quit   - exit the shell");
        }

        private static string getCurrentDirectory()
        {
            string originalDirectory = Directory.GetCurrentDirectory();
            if(string.IsNullOrEmpty(currentDirectory))
            {
                currentDirectory = originalDirectory;
                return originalDirectory;
            }
            else if (currentDirectory!= originalDirectory)
            {
                return currentDirectory;
            }
            return originalDirectory;

        }

    }
}
